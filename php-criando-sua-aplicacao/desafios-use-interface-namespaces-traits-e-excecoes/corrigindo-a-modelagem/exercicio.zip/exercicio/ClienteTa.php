<?php

class ClienteTa
{
    public function __construct(public readonly string $nome, public readonly string $cpf) {}
}
